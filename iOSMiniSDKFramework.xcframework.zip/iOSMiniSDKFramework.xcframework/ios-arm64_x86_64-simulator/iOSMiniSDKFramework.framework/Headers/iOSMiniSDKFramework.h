//
//  iOSMiniSDKFramework.h
//  iOSMiniSDKFramework
//
//  Created by Huseyin Kapi on 20.06.2022.
//  Copyright © 2022 Inoxoft Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for iOSMiniSDKFramework.
FOUNDATION_EXPORT double iOSMiniSDKFrameworkVersionNumber;

//! Project version string for iOSMiniSDKFramework.
FOUNDATION_EXPORT const unsigned char iOSMiniSDKFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iOSMiniSDKFramework/PublicHeader.h>


